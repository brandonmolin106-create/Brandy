ECHO STRIKE - BloodStrike-style shooter inside Minecraft Java 1.20.1
An Echoes in the Dark original.

WHAT'S IN THIS ZIP
  mods/echostrike-1.0.0.jar            the mod (REQUIRED - the guns, movement, enemies and game modes are code)
  saves/Echo Strike/                   the arena world, with the resource pack already inside it
  resourcepacks/Echo-Strike-ResourcePack.zip   the same art as a normal resource pack, in case you want it everywhere

INSTALL (3 steps)
  1. Install Forge or NeoForge for Minecraft 1.20.1 (the Play-Echo-Strike.bat installer does this for you on Windows).
  2. Unzip this file over your .minecraft folder so you end up with .minecraft/mods/echostrike-1.0.0.jar
     and .minecraft/saves/Echo Strike/.
  3. Start the Forge profile, open the "Echo Strike" world. You spawn in the arena with a G18.

CONTROLS
  Left click shoot (hold for full auto)   Right click aim   R reload
  Sprint + crouch = slide                 Run at a block = vault / mantle
  /strike kit     /strike waves start     /strike br start [minutes] [bots]     /strike stop

GUNS: G18, Desert Eagle, MP5, UMP45, Vector, AK-47, M4A1, M870, AWM, M249. All ours, nothing copied.
